1) the root build.xml file contains the test targets we looked at during the presentation

2) it also contains an additional target named "zipThisPresentation".... it's what I used to create the zip file you downloaded

3) the mxunitbuildfile/build.xml is the mxunit build file as of 2/28/2008